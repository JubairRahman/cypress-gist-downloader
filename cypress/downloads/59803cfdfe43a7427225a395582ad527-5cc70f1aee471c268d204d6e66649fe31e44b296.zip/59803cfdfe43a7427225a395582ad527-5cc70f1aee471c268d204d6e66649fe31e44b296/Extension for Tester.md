# Tools for Tester
# Chrome Extension Tools for Different Categories

A curated list of testing tools categorized based on their functionality.

## 1. Exploratory Testing

- [Exploratory Extension](https://chrome.google.com/webstore/detail/exploratory-testing-chrom/khigmghadjljgjpamimgjjmpmlbgmekj/) - A Chrome extension designed for making web exploratory testing easier
- [Auto Form Filler](https://chrome.google.com/webstore/detail/auto-form-filler/cfghpjmgdnienmgcajbmjjemfnnmldlh/) - The extension helps the users to fill a form with junk values on a click of a button.
- [QMetry Exploratory Testing](https://chrome.google.com/webstore/detail/qmetry-test-management-ex/jbnnldpbnobjfgodglhdlbdigibhoacn) - This extension works with QMetry Test Management standalone as well as JIRA app.

## 2. Security & Penetration Testing

- [Tracy](https://chrome.google.com/webstore/detail/tracy/lcgbimfijafcjjijgjoodgpblgmkckhn) - A tool designed to assist with finding all sinks and sources of a web application and display these results in a digestible manner.
- [Request Maker](https://chrome.google.com/webstore/detail/request-maker/kajfghlhfkcocafkcjlajldicbikpgnp) - Request Maker is a tool for penetration testing. With it you can easily capture requests made by web pages, tamper with the URL, headers and POST data and, of course, make new requests.
- [d3Coder](https://chrome.google.com/webstore/detail/d3coder/gncnbkghencmkfgeepfaonmegemakcol) - Encoding/Decoding Plugin for various types of encoding like base64, rot13 or unix timestamp conversion


## 3. API Testing

- [Postman](https://chrome.google.com/webstore/detail/postman/link-to-chrome-extension) - Capture requests from any website within Chrome and send them to Postman Client
- [REST API Inspector](https://chrome.google.com/webstore/detail/rest-api-inspector/lmhkmmkefopogbadhkfcaccjnaihajbh) -This will inspect all the REST API calls & download the API URL along with payload & request detail.
- [JSON Viewer](https://chrome.google.com/webstore/detail/json-viewer/bbdgkoocgebebgihgkhfhlpekclhmfem/) - Makes JSON response easy to read.

- [YuiAPI](https://chrome.google.com/webstore/detail/yuiapi/bnmefgocpeggmnpkglmkfoidibbcogcf/) - An easy-to-use REST client that helps you test the API.

## 4. Extension for Responsiveness

- [Page Ruler Smart](https://chrome.google.com/webstore/detail/page-ruler-smart/dfhpegnjdcbokjipkckekjeicjpicdcc) - Effortlessly Measure Pixel Sizes of Page Elements with Smart Page Ruler.
- [Perfect Pixel](https://chrome.google.com/webstore/detail/perfectpixel-by-welldonec/dkaagdgjmgdmbnecmcefdhjekcoceebi) - This extension helps develop your websites with pixel perfect accuracy!
- [Window Resizer](https://chrome.google.com/webstore/detail/window-resizer/kkelicaakdanhinjdeammmilcgefonfh) - Resize the browser window to emulate various screen resolutions.

## 5. Performance Testing

- [Performance Analyzer](https://chrome.google.com/webstore/detail/performance-analyser/djgfmlohefpomchfabngccpbaflcahjf) - Performance-Analyser is the Chrome Extension version of Performance-Bookmarklet.
### Code: https://github.com/micmro/performance-bookmarklet 

- [Blazemeter](https://chrome.google.com/webstore/detail/blazemeter-the-continuous/mbopgmdnpcbohhpnfglgohlbhfongabi/related) - The BlazeMeter Chrome extension enables you to - Record. Upload. Run.


## 6. UI Testing

- [What Font](https://chrome.google.com/webstore/detail/what-font-font-finder/opogloaldjiplhogobhmghlgnlciebin) - What font? Easy identify the font on a web page, html font size, color and font family.
- [Color Zilla](https://chrome.google.com/webstore/detail/colorzilla/bhlhnicpbhignbdhedgjhgdocnmhomnp) - Advanced Eyedropper, Color Picker, Gradient Generator and other colorful goodies.
- [Spell Checker](https://chrome.google.com/webstore/detail/spell-checker-for-chrome/jfpdnkkdgghlpdgldicfgnnnkhdfhocg) - It's easy to use and fast. This extension supports 25 languages for spell check.
- [IE Tab](https://chrome.google.com/webstore/detail/ie-tab/hehijbfgiekmjfkfjpbkbammjbdenadd) - Display web pages using IE within Chrome. Use Java, Silverlight, ActiveX, Sharepoint & more.
- [Session Manager](https://chrome.google.com/webstore/detail/session-manager/mghenlmbmjcpehccoangkdpagbcbkdpc) - Simple yet powerful tab set management. Quickly & easily save, update, remove & restore sets of tabs!
- [Check My Links](https://chrome.google.com/webstore/detail/check-my-links/ojkcdipcgfaekbeaelaapakgnjflfglf) - Check My Links is a link checker that crawls through your webpage and looks for broken links.

## 7. Accessibility Testing

- [Wave Evaluation Tool](https://chrome.google.com/webstore/detail/wave-evaluation-tool/jbbplnpkjmmeebjpijfedlgcdilocofh) - Evaluate web accessibility within your browser.
- [Accessibility Developer Tool](https://chrome.google.com/webstore/detail/arc-toolkit/chdkkkccnlfncngelccgbgfmjebmkmce) - Accessibility testing tool from TPGi.
- [aXe](https://chrome.google.com/webstore/detail/axe-devtools-web-accessib/lhdoppojpmngadmnindnejefpokejbdd) - Accessibility Checker for Developers, Testers, and Designers in Chrome.
- [Spectrum](https://chrome.google.com/webstore/detail/spectrum/jopdhoinfcaefobmlekemdaikoaaojln) - This extension pipes your logs to Spectrum.
- [Tenon Check](#) - Description of Tenon Check goes here.
- [Siteimprove Accessibility Checker](https://chrome.google.com/webstore/detail/siteimprove-accessibility/djcglbmbegflehmbfleechkjhmedcopn) - Jumpstart your web accessibility efforts directly in Chrome.

## 8. Cookie Testing

- [Edit This Cookie](https://chrome.google.com/webstore/detail/editthiscookie/fngmhnnpilhplaeedifhccceomclgfbg) - EditThisCookie is a cookie manager. You can add, delete, edit, search, protect and block cookies!
- [Clear Cache](https://chrome.google.com/webstore/detail/clear-cache/cppjkneekbjaeellbfkmgnhonkkjfpdn) - Clear your cache and browsing data with a single click of a button.
- [Cookie Editor](https://chrome.google.com/webstore/detail/cookie-editor/hlkenndednhfkekhgcdicdfddnkalmdm) - Simple yet powerful Cookie Editor that allow you to quickly create, edit and delete cookies without leaving your tab.

## 9. Test Evidence

- [Lightshot](https://chrome.google.com/webstore/detail/lightshot-screenshot-tool/mbniclmhobmnbdlbpiphghaielnnpgdp) - Lightshot is the fastest way to take a customizable screenshot. Simple interface, nothing useless and light weight.
- [Screencastify](https://chrome.google.com/webstore/detail/screencastify-screen-vide/mmeijimgabbpbgpdklnllpncmdofkcpn) - The leading screen recorder for Chrome. Capture, edit and share videos in seconds.


---


---

Feel free to add more tools and descriptions to this list. If you have any suggestions or would like to contribute to this list, feel free to create a pull request.
